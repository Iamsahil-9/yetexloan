<?php
echo password_hash("agent@123", PASSWORD_DEFAULT);